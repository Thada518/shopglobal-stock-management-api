class ProductService {
  public async createProduct() {}
}

export default ProductService;
