# shopglobal-stock-management-api

How to deploy 
* download code from last releases.
* Extact your zip and copy your .env.production.local to directory.
* Run npm install
* Run npm run build
* Run npm deploy:prod
